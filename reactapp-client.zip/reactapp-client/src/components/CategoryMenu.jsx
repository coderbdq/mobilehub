import { useEffect, useState } from "react";
import api from "../../utils/apiClient";
import "./CategoryMenu.css";

export default function CategoryMenu() {

  const [categories, setCategories] = useState([]);

  useEffect(() => {
    api.get("/categories")
      .then(res => setCategories(res.data))
      .catch(() => {});
  }, []);

  return (
    <div className="mh-category-menu">
      {categories.map(c => (
        <div key={c.id} className="mh-category-item">
          {c.name}
        </div>
      ))}
    </div>
  );
}
