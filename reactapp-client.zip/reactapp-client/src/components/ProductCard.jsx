import { Link } from "react-router-dom";
import "./ProductCard.css";

export default function ProductCard({ product }) {
  return (
    <div className="col-6 col-md-4 col-lg-3">
      <Link to={`/product/${product.id}`} className="mh-product-card text-decoration-none">
        <div className="card h-100 shadow-sm">
          
          <img src={product.imageUrl} alt={product.name} className="mh-product-img" />

          <div className="card-body">
            <h6 className="mh-product-name">{product.name}</h6>

            <p className="mh-product-price">
              {product.price.toLocaleString("vi-VN")}₫
            </p>

            <p className="mh-product-meta">{product.ram} - {product.storage}</p>
          </div>

        </div>
      </Link>
    </div>
  );
}
