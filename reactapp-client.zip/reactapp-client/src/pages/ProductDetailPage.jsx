// path: reactapp-client/src/pages/ProductDetailPage.jsx
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import userApiClient from "../api/userApiClient";

function formatCurrency(vnd) {
  if (vnd == null) return "";
  return vnd.toLocaleString("vi-VN") + " ₫";
}

function ProductDetailPage() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetail = async () => {
      try {
        const res = await userApiClient.get(`/products/${id}`);
        setProduct(res.data);
      } catch (err) {
        console.error("Lỗi tải chi tiết sản phẩm:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchDetail();
  }, [id]);

  if (loading) return <div className="container py-5">Đang tải...</div>;

  if (!product)
    return (
      <div className="container py-5 text-center text-muted">
        Không tìm thấy sản phẩm.
      </div>
    );

  return (
    <div className="container py-4">
      <div className="row">
        <div className="col-md-5">
          <div className="bg-white rounded-3 p-3 shadow-sm">
            {product.imageUrl ? (
              <img
                src={product.imageUrl}
                alt={product.name}
                className="img-fluid"
              />
            ) : (
              <div className="text-center text-muted py-5">No image</div>
            )}
          </div>
        </div>
        <div className="col-md-7">
          <h3 className="fw-bold">{product.name}</h3>
          <p className="text-muted">{product.brand}</p>
          <div className="fs-4 fw-bold text-danger mb-3">
            {formatCurrency(product.price)}
          </div>
          <ul className="list-unstyled mb-3">
            {product.ram && (
              <li>
                <strong>RAM:</strong> {product.ram}
              </li>
            )}
            {product.storage && (
              <li>
                <strong>Bộ nhớ:</strong> {product.storage}
              </li>
            )}
            {product.color && (
              <li>
                <strong>Màu sắc:</strong> {product.color}
              </li>
            )}
            {product.screenSize && (
              <li>
                <strong>Màn hình:</strong> {product.screenSize}
              </li>
            )}
          </ul>
          <p>{product.description}</p>

          {/* Sau này nối với API /api/cart/add */}
          <button className="btn btn-warning btn-lg">
            Thêm vào giỏ hàng (sẽ làm sau)
          </button>
        </div>
      </div>
    </div>
  );
}

export default ProductDetailPage;
