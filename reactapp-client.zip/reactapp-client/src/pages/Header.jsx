import { Link } from "react-router-dom";
import "./Header.css";

export default function Header() {
  return (
    <header className="mh-header shadow-sm">
      <div className="container d-flex align-items-center justify-content-between py-2">
        
        {/* Logo */}
        <Link to="/" className="mh-logo">
          <img src="/logo.png" alt="MobileHub" />
        </Link>

        {/* Search */}
        <div className="mh-search">
          <input
            type="text"
            placeholder="Bạn tìm gì hôm nay?"
          />
        </div>

        {/* Icons */}
        <div className="mh-actions d-flex align-items-center gap-3">
          <Link to="/cart" className="mh-cart">🛒 Giỏ hàng</Link>
          <Link to="/login" className="mh-login">🔑 Đăng nhập</Link>
        </div>

      </div>
    </header>
  );
}
