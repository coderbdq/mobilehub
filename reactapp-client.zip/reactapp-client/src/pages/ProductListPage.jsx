// path: reactapp-client/src/pages/ProductListPage.jsx
import { useEffect, useState } from "react";
import userApiClient from "../api/userApiClient";
import ProductCard from "../components/ProductCard";

function ProductListPage() {
  const [products, setProducts] = useState([]);
  const [keyword, setKeyword] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await userApiClient.get("/products");
        setProducts(res.data || []);
      } catch (err) {
        console.error("Lỗi tải danh sách sản phẩm:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const filtered = products.filter((p) =>
    (p.name || "").toLowerCase().includes(keyword.toLowerCase())
  );

  return (
    <div className="container">
      <h4 className="fw-bold my-3">Tất cả điện thoại</h4>

      <div className="card mb-3">
        <div className="card-body">
          <div className="row g-2 align-items-center">
            <div className="col-md-6">
              <input
                type="text"
                className="form-control"
                placeholder="Tìm theo tên sản phẩm..."
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
              />
            </div>
            {/* Sau này bạn thêm filter brand, price vào đây */}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-5">Đang tải sản phẩm...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-5 text-muted">
          Không tìm thấy sản phẩm phù hợp.
        </div>
      ) : (
        <div className="row">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}

export default ProductListPage;
