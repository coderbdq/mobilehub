import { useEffect, useState } from "react";
import api from "../apiClient";
import { Link } from "react-router-dom";
import Header from "../components/Header";
import CategoryMenu from "../components/CategoryMenu";
import ProductCard from "../components/ProductCard";
import "./HomePage.css";

export default function HomePage() {

  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await api.get("/products");
      setProducts(res.data);
    } catch (error) {
      console.error("Lỗi tải sản phẩm:", error);
    }
  };

  return (
    <>
      <Header />

      <div className="container mt-3">

        {/* Banner */}
        <div className="mh-banner mb-4">
          <img
            src="/banner-mobilehub.png"
            className="img-fluid rounded"
            alt="Banner"
          />
        </div>

        {/* Category Menu */}
        <CategoryMenu />

        {/* Product list */}
        <h3 className="fw-bold mt-4 mb-3">🔥 Điện thoại nổi bật</h3>

        <div className="row g-3">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>
    </>
  );
}
