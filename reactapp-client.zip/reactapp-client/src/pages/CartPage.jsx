// path: reactapp-client/src/pages/CartPage.jsx
function CartPage() {
  // Bước sau: gọi /api/cart, hiển thị items, cho sửa số lượng, xóa...
  return (
    <div className="container py-4">
      <h4 className="fw-bold mb-3">Giỏ hàng</h4>
      <div className="text-muted">
        Chức năng giỏ hàng sẽ được nối với API /api/cart ở bước tiếp theo.
      </div>
    </div>
  );
}

export default CartPage;
