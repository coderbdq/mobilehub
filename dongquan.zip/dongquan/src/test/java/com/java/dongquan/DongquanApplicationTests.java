package com.java.dongquan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DongquanApplicationTests {

	@Test
	void contextLoads() {
	}

}
