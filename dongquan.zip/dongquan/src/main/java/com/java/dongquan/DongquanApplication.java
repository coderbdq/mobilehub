package com.java.dongquan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DongquanApplication {

	public static void main(String[] args) {
		SpringApplication.run(DongquanApplication.class, args);
	}

}
